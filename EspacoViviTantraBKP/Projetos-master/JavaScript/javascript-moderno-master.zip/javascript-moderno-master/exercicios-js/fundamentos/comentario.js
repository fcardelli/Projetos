// Comentário de uma linha
console.log('Linha 1')

/*
 Comentário de
 múltiplas linhas
*/
console.log('Linha 2')

/*
 * Comentário de
 * múliplas linhas
 */
console.log('Linha 3')