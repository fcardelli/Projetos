var a = 3;
var b = 4;
a = 20;

let c = 30;
var b = 40;
//let c = 35;
c = 25;

const d = 5;
//d = 40;

a = 20;


console.log(a,b,c,d);
// Var permite ser declarada novamente e permite que os valores sejam alterados.
// 