let valor //Não inicializada
console.log(valor)