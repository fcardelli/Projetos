let qualquer = 'legal';
console.log(qualquer);
qualquer = 3.151515;
console.log(typeof qualquer);
console.log(qualquer);
