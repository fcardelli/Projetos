namespace EspacoViviTantra.Domain.Models
{
    public class TipoEndereco
    {
        public int Id { get; set; }
        public string Descricao { get; set; }
    }
}