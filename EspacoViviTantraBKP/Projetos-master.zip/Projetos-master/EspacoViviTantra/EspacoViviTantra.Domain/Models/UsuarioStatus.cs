namespace EspacoViviTantra.Domain.Models
{
    public class UsuarioStatus
    {
        public int Id { get; set; }
        public string Descricao { get; set; }
    }
}