namespace EspacoViviTantra.Domain.Models
{
    public class TipoPost
    {
        public int Id { get; set; }
        public string Descricao { get; set; }
    }
}