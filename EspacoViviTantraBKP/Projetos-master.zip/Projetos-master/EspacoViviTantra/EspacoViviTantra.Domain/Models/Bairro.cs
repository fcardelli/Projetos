namespace EspacoViviTantra.Domain.Models
{
    public class Bairro
    {
        public int Id { get; set; }
        public string Nome { get; set; }
    }
}