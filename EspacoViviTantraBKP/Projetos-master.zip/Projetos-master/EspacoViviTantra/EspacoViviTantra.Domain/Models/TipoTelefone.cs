namespace EspacoViviTantra.Domain.Models
{
    public class TipoTelefone
    {
        public int Id { get; set; }
        public string Descricao { get; set; }
    }
}